import time
print("Install Class.js")
print("Type the edition you would like to install.")
edition=input("")
print("Installing", edition, "v2.1...")
time.sleep(30)
