# class.js
A simple developer javascript library for class based [html](https://github.com/topics/html) and [ibl](https://github.com/SaiCorporation/ibl) programs
