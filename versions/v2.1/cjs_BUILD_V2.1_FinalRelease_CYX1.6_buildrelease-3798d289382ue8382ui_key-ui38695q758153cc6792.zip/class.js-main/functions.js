function transfer(){
   window.location.href = "https://saicorporation.github.io/class.js/transfer";
}

function jcaptcha() {
  alert("Click OK to verify you are not a robot.");
  alert("Recorded on" + Date());
}
function open(link4432){
  window.location.href = "link4432";
}
//Canvas is canvases: changeimage function
function setimageincanvas(canvasid, image) {
   // Sets active canvas to canvasid variable
  setActiveCanvas(canvasid);
   // Changes bg-img to image variable
  drawImageURL(image);
}
