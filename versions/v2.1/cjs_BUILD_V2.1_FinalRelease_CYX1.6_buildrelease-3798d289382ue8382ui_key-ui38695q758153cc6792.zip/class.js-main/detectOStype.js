        var Name = "Unknown OS";
        if (navigator.userAgent.indexOf("Win") != -1) OSType = 
          "Windows OS";
        if (navigator.userAgent.indexOf("Mac") != -1) OSType = 
          "Macintosh";
        if (navigator.userAgent.indexOf("Linux") != -1) OSType = 
          "Linux OS";
        if (navigator.userAgent.indexOf("Android") != -1) OSType = 
          "Android OS";
        if (navigator.userAgent.indexOf("like Mac") != -1) OSType = 
          "iOS";
