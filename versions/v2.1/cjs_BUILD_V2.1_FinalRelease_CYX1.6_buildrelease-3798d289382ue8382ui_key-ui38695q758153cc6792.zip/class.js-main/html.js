function transfer(){
   window.location.href = "https://saicorporation.github.io/class.js/transfer";
}

function jcaptcha() {
  alert("Click OK to verify you are not a robot.");
  alert("Recorded on" + Date());
}
