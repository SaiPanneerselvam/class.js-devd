function getemplate(type){
alert("Loading template...")
alert('Please dismiss the next dialogue, if you dont want the debug info.")
alert("program.choice()")
}
