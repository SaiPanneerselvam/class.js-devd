var cut = "Cut"
function juice(){
window.alert("JUICE")}
call juice()
