const navy = Date()
let fs = var
fs installer = "js.preview"
fs sc = "os.cornmeal"
window.alert(sc)
