var date = Date()
var datetext = "date"
var $cents = "451"
var is = "is"
var wr = "written"
var the = "the"
alert(the, datetext, is, date )